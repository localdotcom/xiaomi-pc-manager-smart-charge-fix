# Xiaomi PC Manager smart charge fix
## Description
The powershell script to fix Xiaomi PC Manager smart charge issue described
[here](https://github.com/Data-Name-ID/RedmiBook-Pro-14-2024?tab=readme-ov-file#%D0%BE%D0%BF%D1%82%D0%B8%D0%BC%D0%B8%D0%B7%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%BD%D0%B0%D1%8F-%D0%B7%D0%B0%D1%80%D1%8F%D0%B4%D0%BA%D0%B0-%D0%B4%D0%BE-80)
## Installation
- [Download](https://github.com/localdotcom/xiaomi-pc-manager-smart-charge-fix/releases) and unzip latest release
- Run `init.ps1`
- Restart the laptop
## Testing
- Plug the power adapter
- Check whether file `.plugged` is created in the script directory 
